import os

def createNewPart(partName,parent='part'):
	#open the file, read ('r') the data, close the file
	f = open(os.path.join(__path__[0],'example'),'r')
	data = f.read()
	f.close()

	#create your new part .py file, replace variables with your names, write ('w') the file, close the file
	f = open(os.path.join(__path__[0],'{0}.py'.format(partName)),'w')
	partData = data.format(PARENT=parent,PARENTUPPER=parent.capitalize(),EXAMPLE=partName.capitalize())
	f.write(partData)
	f.close()