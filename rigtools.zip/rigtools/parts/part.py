'''
Part module
Builds a generic part rig
'''

#Import maya modules
import maya.cmds as cmds

#Import package modules
import rigtools.libs.name as rigName
import rigtools.libs.control as rigControl
import rigtools.libs.joint as rigJoint
import rigtools.libs.ikfk as rigIkFk

class Part(object):

	puppetNode = 'puppet'

	def __init__(self,name):
		'''
		Initialize method

		Parameters:
		name (str) = the name assigned to the Part
		'''
		self._name = name
		self._side = self.getSide(name)

		#Define setup group attributes
		self._setupGroup = '{0}_setup_{1}'.format(name, rigName.GROUP)
		self._skeletonGroup = '{0}_skeleton_{1}'.format(name, rigName.GROUP)
		self._guidesGroup = '{0}_guides_{1}'.format(name, rigName.GROUP)
		self._masterGuide = rigControl.Guide('{0}_master_{1}'.format(name,rigName.GUIDE),self._guidesGroup,'circle',color=4)

		self._anchor = str()
		self._hook = str()		

		#Define build group attributes
		self._rigGroup = '{0}_rig_{1}'.format(name, rigName.GROUP)
		self._jointsGroup = '{0}_joints_{1}'.format(name, rigName.GROUP)
		self._controlsGroup = '{0}_controls_{1}'.format(name, rigName.GROUP)
		self._noXformGroup = '{0}_noXform_{1}'.format(name, rigName.GROUP)
		self._controlScale = 1

		self._color = rigName.YELLOW
		if self._side == rigName.LEFT:
			self._color = rigName.BLUE
		elif self._side == rigName.RIGHT:
			self._color = rigName.RED
	

	#----------GETS-----------
	def getName(self):
		'''
		Returns value set for name
		'''
		return self._name


	@staticmethod	
	def getSide(name):
		'''
		Gets side and location prefixes for a given name
		'''
		#Get side and location from name.py module
		side = rigName.getSide(name)
		location = rigName.getLocation(name)
		
		#Check that side exists and is named per the NAMETEMPLATE format
		if not side:
			raise RuntimeError('{0} must follow {1} naming convention'.format(name,rigName.NAMETEMPLATE))

		#Set sideLocation
		sideLocation = side
		
		#Check if location exists and append it to sideLocation
		if location:
			sideLocation = '{0}_{1}'.format(side,location)

		return sideLocation


	#----------SETS-----------

	#----------SETUP----------

	def setup(self):
		'''
		Creates setup group hierarchy
		'''
		#Create setupGroup hierarchy
		if not cmds.objExists(Part.puppetNode):
			cmds.createNode('transform',n=Part.puppetNode)

		cmds.createNode('transform',n=self._setupGroup)
		cmds.createNode('transform',n=self._skeletonGroup,parent=self._setupGroup)
		cmds.createNode('transform',n=self._guidesGroup,parent=self._setupGroup)

		#Create the masterGuide and scale it up
		masterGuide = self._masterGuide.create()
		#cmds.setAttr(masterGuide+'.scaleX', 2)
		#cmds.setAttr(masterGuide+'.scaleY', 2)
		#cmds.setAttr(masterGuide+'.scaleZ', 2)
		self._masterGuide.scale(self._masterGuide.getName(),
								scale=[self._controlScale*2,self._controlScale*2,self._controlScale*2])
		
				
	def postSetup(self):
		'''
		Cleans up setup method
		'''
		
		#add attribute to the master guide to toggle display axis on joints
		masterGuide = self._masterGuide.getName()

		cmds.addAttr(masterGuide,ln='displayAxis',at='enum',enumName='Off:On',dv=1,keyable=True)
		displayAxisAttr = '{0}.displayAxis'.format(masterGuide)

		for jnt in cmds.listRelatives(self._skeletonGroup,ad=True,type='joint'):
			#check the Enable Overrides box under Drawing Overides in the attribute editor
			cmds.setAttr('{0}.overrideEnabled'.format(jnt),1)
			#set display type to reference so joints are not selectable in the viewport
			cmds.setAttr('{0}.overrideDisplayType'.format(jnt),2)
			#connect display axis attribute to display local axis override
			cmds.connectAttr(displayAxisAttr,'{0}.displayLocalAxis'.format(jnt),f=True)
		
		cmds.parent(self._setupGroup,Part.puppetNode)

	def runSetup(self):
		'''
		runs setup and postSetup methods
		'''

		self.setup()
		self.postSetup()


	#----------BUILD----------

	def preBuild(self):
		'''
		prepares for the build
		'''
		#set display axis attribute to off
		masterGuide = self._masterGuide.getName()
		cmds.setAttr('{0}.displayAxis'.format(masterGuide),0)
		
		#set display type to normal so joints are selectable in the viewport
		for jnt in cmds.listRelatives(self._skeletonGroup,ad=True,type='joint'):
			cmds.setAttr('{0}.overrideDisplayType'.format(jnt),0)


	def build(self):
		'''
		Builds rig group hierarchy
		'''
		#Create rigGroup hierarchy
		if cmds.objExists(self._rigGroup):
			return

		cmds.createNode('transform',n=self._rigGroup)
		cmds.createNode('transform',n=self._jointsGroup,parent=self._rigGroup)
		cmds.createNode('transform',n=self._controlsGroup,parent=self._rigGroup)
		cmds.createNode('transform',n=self._noXformGroup,parent=self._rigGroup)

		if cmds.objExists(self._guidesGroup):
			cmds.delete(self._guidesGroup)

		if cmds.objExists(self._skeletonGroup):
			children = cmds.listRelatives(self._skeletonGroup,c=True,type='joint')
			joints = cmds.listRelatives(self._skeletonGroup,ad=True,type='joint')
			if children:
				cmds.parent(children,self._jointsGroup)

			for jnt in joints:
				rigJoint.rotateToOrient(jnt)

		cmds.delete(self._setupGroup)


	def postBuild(self):
		'''
		Cleans up build method
		'''


	def runBuild(self):
		'''
		runs preBuild, build and postBuild methods
		'''

		self.preBuild()
		self.build()
		self.postBuild()


	#GUIDES
	def createGuide(self,name,joint,color=0):
		'''
		'''
		if not cmds.objExists(joint):
			raise RuntimeError('{0} does not exist'.format(joint))

		guide = rigControl.Guide.createGuide('{0}_guide'.format(joint),self._masterGuide.getName(),'sphere',color)

		#Get joint position
		jointPos = cmds.xform(joint,q=True,ws=True,rp=True)

		#Move guide to joint's position
		guide.setPosition(jointPos)

		#Point constrain joint to the guide
		cst = cmds.pointConstraint(guide.getName(),joint)

		#Parent the constraint to the guidesGroup
		cmds.parent(cst,self._guidesGroup)

		return guide
	

	