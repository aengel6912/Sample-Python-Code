'''
Arm module
'''
#Import maya modules
import maya.cmds as cmds

#Import package modules
import rigtools.parts.limb as rigLimb
reload(rigLimb)
import rigtools.libs.name as rigName
import rigtools.libs.joint as rigJoint
import rigtools.libs.control as rigControl

class Arm(rigLimb.Limb):
	def __init__(self,name):
		'''
		'''
		super(Arm,self).__init__(name)

		#define clavicle joint
		side = self.getSide(name)		
		self._clavicleJoint = '{0}_clavicle_{1}'.format(side,rigName.JOINT)

		#rename limb joints
		self._startJoint = '{0}_shoulder_{1}'.format(side,rigName.JOINT)
		self._middleJoint = '{0}_elbow_{1}'.format(side,rigName.JOINT)
		self._endJoint = '{0}_wrist_{1}'.format(side,rigName.JOINT)

		#insert a position into self._positions for the clavicle joint
		if side == rigName.LEFT:
			self._positions = [(1,20,0),(2,20,0),(7,20,-2),(12,20,0)]
		elif side == rigName.RIGHT:
			self._positions = [(-1,20,0),(-2,20,0),(-7,20,-2),(-12,20,0)]


	def getPositions(self):
		'''
		inserts the position of the clavicle joint into the positions list returned in limb.py
		'''
		#run getPositions from parent class and store the returned value in a variable called positions
		positions = super(Arm,self).getPositions()

		#insert the poisition of the clavicle joint into the positions list
		if cmds.objExists(self._clavicleJoint):
			positions.insert(0,cmds.xform(self._clavicleJoint,q=True,ws=True,t=True))

			return positions

		return self._positions


	def setup(self):
		'''
		'''
		#change position stored in limb.py to clavicle joint position defined in init method
		claviclePosition = self._positions.pop(0)
		
		#run setup from parent class
		super(Arm,self).setup()

		#change position back to what it was prior to adding a clavicle joint
		self._positions.insert(0,claviclePosition)

		#get the children of the masterguide (individual guides)
		masterGuideName = self._masterGuide.getName()
		guideNuls = cmds.listRelatives(masterGuideName,c=True,type='transform')
		
		#parent the individual guides to the guides group
		cmds.parent(guideNuls,self._guidesGroup)

		#move the masterguide to the clavicle position
		self._masterGuide.setPosition(claviclePosition)

		#parent the individual guides back to the masterguide
		cmds.parent(guideNuls,masterGuideName)		

		#create clavicle joint and guide
		if not cmds.objExists(self._clavicleJoint):
			rigJoint.createJoint(self._clavicleJoint,position=self._positions[0],parent=self._skeletonGroup)
			guide = self.createGuide('{0}_{1}'.format(self._clavicleJoint,rigName.GUIDE),self._clavicleJoint,color=self._color)
		else:
			if not cmds.objExists('{0}_{1}'.format(self._clavicleJoint,rigName.GUIDE)):
				guide = self.createGuide('{0}_{1}'.format(self._clavicleJoint,rigName.GUIDE),self._clavicleJoint,color=self._color)

		#parent the existing limb's start joint to the clavicle joint
		cmds.parent(self._startJoint,self._clavicleJoint)

		#create an aim locator
		aimLocator = cmds.spaceLocator(name='{0}_aim'.format(self._clavicleJoint))[0]

		#parent the locator to guides group
		cmds.parent(aimLocator,self._guidesGroup)

		#move the locator to the clavicle guide
		guidePosition = guide.getPosition()
		cmds.xform(aimLocator,ws=True,t=guidePosition)
		if rigName.getSide(self._name) == rigName.LEFT:
			cmds.xform(aimLocator,r=True,t=[1,0,0])
		if rigName.getSide(self._name) == rigName.RIGHT:
			cmds.xform(aimLocator,r=True,t=[-1,0,0])


		#hide the locator
		cmds.setAttr('{0}.v'.format(aimLocator),0)

		#point constrain the locator to the clavicle guide
		cmds.pointConstraint(guide.getName(),aimLocator,mo=True)

		#aim constrain the clavicle joint to the aim locator
		cst = cmds.aimConstraint(aimLocator,self._clavicleJoint,worldUpType='vector')[0]

		#connect aim and up axis attributes to the constraint
		cmds.connectAttr(self._aimAxisAttr, '{0}.aimVector'.format(cst), f=True)
		cmds.connectAttr(self._upAxisAttr, '{0}.upVector'.format(cst), f=True)

		#offset the aim locator
		if rigName.getSide(self._name) == rigName.LEFT:
			cmds.xform(aimLocator,r=True,t=[1,0,0])
		if rigName.getSide(self._name) == rigName.RIGHT:
			cmds.xform(aimLocator,r=True,t=[-1,0,0])
			#flip the world up vector in Y for the right side
			cmds.setAttr('{0}.worldUpVectorY'.format(cst),-1)

		#parent the constraint to the guides group
		cmds.parent(cst,self._guidesGroup)		

	def build(self):
		'''
		creates fk control for the clavicle joint, adds ikfk functionality, and creates a no twist joint for the upper arm
		'''
		#run build from parent class
		super(Arm,self).build()

	#----------CLAVICLE CONTROL----------
		#create a control for the clavicle joint
		clavicleControlName = '{0}_{1}'.format(self._clavicleJoint.replace('_{0}'.format(rigName.JOINT),''),rigName.CONTROL)
		clavicleControl = rigControl.Control.createControl(name=clavicleControlName,parent=self._controlsGroup,shape='sphere',color=self._color)

		#move the control to clavicle joint
		clavicleControl.setPosition(cmds.xform(self._clavicleJoint,q=True,ws=True,t=True))

		#position the control into clavicle joint's space
		clavicleControl.setRotate(cmds.xform(self._clavicleJoint,q=True,ws=True,ro=True))
		clavicleControl.setRotateOrder(cmds.xform(self._clavicleJoint,q=True,roo=True))

		#parent constrain the clavicle joint to the control
		cmds.pointConstraint(clavicleControlName,self._clavicleJoint)

		#add the parameter node to the control
		cmds.parent(self._paramNode,clavicleControlName,s=True,r=True,add=True)

	#----------IKFK FUNCTIONALITY----------
		#get a list of fk controls that were stored on the paramNode in limb.py
		fkControls = cmds.getAttr('{0}.fkControls'.format(self._paramNode)).split()

		#parent the first control's null to the clavicle control
		fkControlObj = rigControl.Control(fkControls[0])
		fkNull = fkControlObj.getNullGroup()
		cmds.parent(fkNull,clavicleControlName)

		#parent constrain the first ik joint to the clavicle control
		ikJoints = self._ikfkSystem.getIkJoints()
		cmds.parentConstraint(clavicleControlName,ikJoints[0],mo=True)

	#----------NO TWIST JOINT----------
		#duplicate the original start joint to create the no twist joint
		originalJoints = self._ikfkSystem.getOriginalJoints()
		noTwistJoint = cmds.duplicate(originalJoints[0],n='{0}.noTwist_{1}'.format(self._name,rigName.JOINT),rr=True,po=True)

		#aim constrain no twist joint to original elbow joint
		cmds.aimConstraint(originalJoints[1],noTwistJoint,worldUpType='none',u=self._upAxis,aim=self._aimAxis)

