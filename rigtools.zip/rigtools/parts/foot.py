'''
Foot module
'''

#Import maya modules
import maya.cmds as cmds
import maya.mel as mm

#Import package modules
import rigtools.parts.part as rigPart
import rigtools.libs.ikfk as rigIkFk
reload(rigIkFk)
import rigtools.libs.name as rigName
import rigtools.libs.attribute as rigAttr
import rigtools.libs.joint as rigJoint
import rigtools.libs.control as rigControl


class Foot(rigPart.Part):
	def __init__(self,name):
		'''
		constructor method
		'''
		super(Foot,self).__init__(name)

		#define class variables
		side = self.getSide(name)

		self._footJoint = '{0}_foot_{1}'.format(side,rigName.JOINT)
		self._ballJoint = '{0}_ball_{1}'.format(side,rigName.JOINT)
		self._toeJoint = '{0}_toe_{1}'.format(side,rigName.JOINT)


		#define positions for foot joints
		if side == rigName.LEFT:
			self._positions = [(2,2,0),(2,0,3),(2,0,5)]
		elif side == rigName.RIGHT:
			self._positions = [(-2,2,0),(-2,0,3),(-2,0,5)]	
		

	def setup(self):
		'''
		setup function
		'''
		super(Foot,self).setup()

		#create foot joints

		parent = self._skeletonGroup
		guides = []

		self._masterGuide.setPosition(self._positions[0])

		#Create up and aim axis attributes on the masterGuide
		if rigName.getSide(self._name) == rigName.LEFT:
			upAxisAttr = rigAttr.switch('upAxis',self._masterGuide.getName(),value=1,
				choices = ['x','y','z','-x','-y','-z'], outputs = [(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)])
			aimAxisAttr = rigAttr.switch('aimAxis',self._masterGuide.getName(),value=0,
				choices = ['x','y','z','-x','-y','-z'], outputs = [(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)])

		if rigName.getSide(self._name) == rigName.RIGHT:
			upAxisAttr = rigAttr.switch('upAxis',self._masterGuide.getName(),value=4,
				choices = ['x','y','z','-x','-y','-z'], outputs = [(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,1,0),(0,0,-1)])
			aimAxisAttr = rigAttr.switch('aimAxis',self._masterGuide.getName(),value=0,
				choices = ['x','y','z','-x','-y','-z'], outputs = [(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,1,0),(0,0,-1)])
		
		#store aim and up axis attributes as class attributes
		self._aimAxisAttr = aimAxisAttr
		self._upAxisAttr = upAxisAttr

		for i,jnt in enumerate([self._footJoint,self._ballJoint,self._toeJoint]):
			if not cmds.objExists(jnt):
				rigJoint.createJoint(jnt,position=self._positions[i],parent=parent)
				guide = self.createGuide('{0}_{1}'.format(jnt,rigName.GUIDE),jnt,color=self._color)
			else:
				if not cmds.objExists('{0}_{1}'.format(jnt,rigName.GUIDE)):
					guide = self.createGuide('{0}_{1}'.format(jnt,rigName.GUIDE),jnt,color=self._color)

			guides.append(guide)
			parent = jnt		
		
		footGuideName = guides[0].getName()
		ballGuideName = guides[1].getName()
		toeGuideName = guides[2].getName()

		self._ikfkSystem = rigIkFk.IkFkFoot([self._footJoint,self._ballJoint,self._toeJoint])
		footRollGroups = self._ikfkSystem.getFootGroups()
		footRollGroups[0].setParent(self._masterGuide.getName())
		self._ikfkSystem.createGroups()

		#set footRollGroup names and turn on the display handles
		for grp in footRollGroups:
			grp.setName('{0}_{1}'.format(self._side,grp.getName()))
			cmds.setAttr('{0}.displayHandle'.format(grp.getName()),1)

		#position the display handle for the footRollGroups at the first roll group 
		#rootFootRollGrp = mm.eval('rootOf("{0}")'.format(grp)).split('|')[-1]
		#cmds.parent(footRollGroups[0].getName(),self._masterGuide.getName())

	def postSetup(self):
		'''
		post setup cleanup
		'''
		super(Foot,self).postSetup()


	def preBuild(self):
		'''
		'''
		super(Foot,self).preBuild()


	def build(self):
		'''
		build function
		'''
		#store first value of aim and up axis attributes and then delete them
		self._aimAxis = cmds.getAttr(self._aimAxisAttr)[0]
		self._upAxis = cmds.getAttr(self._upAxisAttr)[0]
		del(self._aimAxisAttr)
		del(self._upAxisAttr)

		#rename ankle driver
		self._ikfkSystem.setAnkleDriver('{0}_ankleDriver'.format(self._name))

		#get foot roll groups
		footRollGroups = self._ikfkSystem.getFootGroups()

		#parent the first foot roll group to the world
		cmds.parent(footRollGroups[0].getName(),w=True)

		super(Foot,self).build()

		#check that joints exist
		for joint in [self._footJoint,self._ballJoint,self._toeJoint]:
			if not cmds.objExists(joint):
				raise RuntimeError('{0} does not exist in the scene'.format(joint))

		self._ikfkSystem.create()

		self._ikfkSystem.setGroupName('{0}_ikfk'.format(self._name))

		#get joints
		originalJoints = self._ikfkSystem.getOriginalJoints()
		blendJoints = self._ikfkSystem.getBlendJoints()
		ikJoints = self._ikfkSystem.getIkJoints()
		fkJoints = self._ikfkSystem.getFkJoints()
		ikfkGroup = self._ikfkSystem.getGroup()
		handles = self._ikfkSystem.getHandle()

		cmds.parent(ikfkGroup,self._controlsGroup)


	#----------PARAMNODE----------
		#create a parameter node (a locator's shape node)
		nameSplit = self._name.split(rigName.DELIMITER)
		side = self.getSide(self._name)
		if len(side) > 1:
			for name in side.split('_'):
				nameSplit.remove(name)

		paramNode = cmds.createNode('locator',n='{0}_{1}'.format('_'.join(nameSplit),side.title()))
		
		#parent the paramNode's shape to the ... and delete the leftover empty node
		paramParent = cmds.listRelatives(paramNode,p=True)

		#turn off visibility
		cmds.setAttr('{0}.visibility'.format(paramNode),0)

		#lock and hide shape attributes
		for attr in ('lpx','lpy','lpz','lsx','lsy','lsz'):
			rigAttr.lockAndHideAttr(paramNode,attr)

		#add ikfk switch attribute to parameter node and connect it to the ikfk switch attribute on the ikfk group
		cmds.addAttr(paramNode,ln='ikfk',at='double',min=0,max=1,dv=0,keyable=True)
		ikfkAttribute = '{0}.{1}'.format(paramNode,'ikfk')
		cmds.connectAttr(ikfkAttribute, '{0}.ikfk'.format(ikfkGroup),f=True)

	#----------IK CONTROLS----------		
		#create ik controls
		ikControl = rigControl.Control('{0}_{1}'.format(ikJoints[0].replace('{0}'.format(rigName.JOINT),''),rigName.CONTROL),
														parent = self._controlsGroup,
														shape = 'sphere',
														color = self._color,
														position = cmds.xform(ikJoints[0],q=True,ws=True,t=True))

		ikControl.create()
		ikControlName = ikControl.getName()
		self._ikControl = ikControl

		#parent the first foot roll group to the ikControl
		footRollGroups[0].setParent(ikControl.getName())		

		#add the paramNode to the ik control
		cmds.parent(paramNode,ikControlName,r=True,s=True,add=True)
		cmds.delete(paramParent)

	#----------VISIBILITY----------
		#create and connect reverse node for control visibility
		reverseNode = cmds.createNode('reverse',n='{0}_{1}'.format(self._name,rigName.REVERSE))
		cmds.connectAttr(ikfkAttribute,'{0}.inputX'.format(reverseNode),f=True)
		for ctrl in [ikControlName]:
			for shape in rigControl.Control.getShapes(ctrl):
				if shape != paramNode:
					cmds.connectAttr('{0}.outputX'.format(reverseNode),'{0}.v'.format(shape),f=True)	

		#turn off the visibility for the ik handles
		for handle in handles:
			cmds.setAttr('{0}.v'.format(handle),0)

		#turn off the display handles for the footRollGroups
		for grp in footRollGroups:
			cmds.setAttr('{0}.displayHandle'.format(grp.getName()),0)

		#turn off the visibility for the ik, fk and blend joint chains
		for joint in [blendJoints[0],ikJoints[0],fkJoints[0]]:
			cmds.setAttr('{0}.v'.format(joint),0)

		#set display axis attribute to off
		#cmds.setAttr('{0}.displayAxis'.format(self._masterGuide.getName()),0)

	#----------ATTRIBUTES----------	
		#Define the attribute variables
		bankIn = footRollGroups[1]
		bankOut = footRollGroups[2]
		heelPivot = footRollGroups[3]
		heelRoll = footRollGroups[4]
		ballPivot = footRollGroups[5]
		toePivot = footRollGroups[6]
		toeRoll = footRollGroups[7]
		toeBend = footRollGroups[8]
		ballRoll = footRollGroups[-1]

		#Create the attributes
		cmds.addAttr(ikControlName,ln='FOOT',at='double',dv=0,keyable=True)	
		rigAttr.lockAttr(ikControlName,'FOOT')	
		cmds.addAttr(ikControlName,ln='bank',at='double',dv=0,keyable=True)
		cmds.addAttr(ikControlName,ln='heelPivot',at='double',dv=0,keyable=True)
		cmds.addAttr(ikControlName,ln='heelRoll',at='double',dv=0,max=0,keyable=True)
		cmds.addAttr(ikControlName,ln='ballPivot',at='double',dv=0,keyable=True)
		cmds.addAttr(ikControlName,ln='toePivot',at='double',dv=0,keyable=True)
		cmds.addAttr(ikControlName,ln='toeRoll',at='double',dv=0,min=0,keyable=True)
		cmds.addAttr(ikControlName,ln='toeBend',at='double',dv=0,keyable=True)
		cmds.addAttr(ikControlName,ln='ballRoll',at='double',dv=0,min=0,keyable=True)		

		#Connect the attributes					
		cmds.connectAttr('{0}.bank'.format(ikControlName),'{0}.rz'.format(bankIn.getName()),f=True)
		cmds.transformLimits(bankIn.getName(),rz=[0,45],erz=[1,0])
		cmds.connectAttr('{0}.bank'.format(ikControlName),'{0}.rz'.format(bankOut.getName()),f=True)
		cmds.transformLimits(bankOut.getName(),rz=[-45,0],erz=[0,1])
		cmds.connectAttr('{0}.heelPivot'.format(ikControlName),'{0}.ry'.format(heelPivot.getName()),f=True)
		cmds.connectAttr('{0}.heelRoll'.format(ikControlName),'{0}.rx'.format(heelRoll.getName()),f=True)
		cmds.connectAttr('{0}.ballPivot'.format(ikControlName),'{0}.ry'.format(ballPivot.getName()),f=True)
		cmds.connectAttr('{0}.toePivot'.format(ikControlName),'{0}.ry'.format(toePivot.getName()),f=True)
		cmds.connectAttr('{0}.toeRoll'.format(ikControlName),'{0}.rx'.format(toeRoll.getName()),f=True)
		cmds.connectAttr('{0}.toeBend'.format(ikControlName),'{0}.rx'.format(toeBend.getName()),f=True)		
		cmds.connectAttr('{0}.ballRoll'.format(ikControlName),'{0}.rx'.format(ballRoll.getName()),f=True)

	#----------FK CONTROLS----------
		#
		fkControls = list()
		#add an attribute to the paramNode to store the fkControls
		cmds.addAttr(paramNode,ln='fkControls',dt='string')
		fkControlsStr = str()

		parent = self._controlsGroup
		for i in range(len(originalJoints)):
			cmds.parentConstraint(blendJoints[i],originalJoints[i])
			
			#create and position fk controls
			fkControlName = '{0}_{1}'.format(fkJoints[i].replace('_{0}'.format(rigName.JOINT),''),rigName.CONTROL)
			fkControl = rigControl.Control.createControl(name=fkControlName,parent=parent,shape='circle',color=self._color)
			fkControl.setPosition(cmds.xform(fkJoints[i],q=True,ws=True,t=True))
			fkControl.setRotate(cmds.xform(fkJoints[i],q=True,ws=True,ro=True))
			fkControl.setRotateOrder(cmds.xform(fkJoints[i],q=True,roo=True))
			cmds.pointConstraint(fkControl.getName(),fkJoints[i])
			cmds.orientConstraint(fkControl.getName(),fkJoints[i])
			
			cmds.parent(paramNode,fkControl.getName(),r=True,s=True,add=True)
			parent = fkControl.getName()

			#connect paramNode to visibility
			for shape in rigControl.Control.getShapes(fkControl.getName()):
				if shape != paramNode:
					cmds.connectAttr(ikfkAttribute,'{0}.v'.format(shape),f=True)

			#store fkControls for use later
			fkControlsStr = fkControlsStr + ' ' + fkControl.getName()
			fkControls.append(fkControl)

		#set the fkControls on the fkControls attribute on the paramNode
		cmds.setAttr('{0}.fkControls'.format(paramNode),fkControlsStr,type='string')


	def postBuild(self):
		'''
		post build cleanup
		'''
		super(Foot,self).postBuild()


	def runBuild(self):
		'''
		runs preBuild, build and postBuild methods		
		'''
		self.preBuild()
		self.build()
		self.postBuild()