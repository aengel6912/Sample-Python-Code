'''
Arm module
'''
#Import maya modules
import maya.cmds as cmds

#Import package modules
import rigtools.parts.arm as rigArm
import rigtools.libs.name as rigName


class Leg(rigArm.Arm):
	def __init__(self,name):
		'''
		'''
		super(Leg,self).__init__(name)

		#define pelvis joint
		side = self.getSide(name)		
		self._clavicleJoint = '{0}_pelvis_{1}'.format(side,rigName.JOINT)

		#Rename limb joints
		self._startJoint = '{0}_thigh_{1}'.format(side,rigName.JOINT)
		self._middleJoint = '{0}_knee_{1}'.format(side,rigName.JOINT)
		self._endJoint = '{0}_ankle_{1}'.format(side,rigName.JOINT)

		#define positions for leg joints
		if side == rigName.LEFT:
			self._positions = [(1,13,0),(2,12,0),(2,7,2),(2,2,0)]
		elif side == rigName.RIGHT:
			self._positions = [(-1,13,0),(-2,12,0),(-2,7,2),(-2,2,0)]	


	def setup(self):
		'''
		'''
		#run setup from parent class		
		super(Leg,self).setup()

		#get the aim locator
		aimLocator = '{0}_aim'.format(self._clavicleJoint)

		#delete the children of the aim locator (the point constraint created in arm.py)
		cmds.delete(cmds.listRelatives(aimLocator,c=True))

		#move the aim locator to the clavicle (pelvis) joint and offset in Y
		claviclePosition = cmds.xform(self._clavicleJoint,q=True,ws=True,t=True)
		cmds.xform(aimLocator,ws=True,t=[claviclePosition[0],claviclePosition[1]-1,claviclePosition[2]])

		#get all aim constraints in the guides group
		aimCstList = cmds.listRelatives(self._guidesGroup,c=True,type='aimConstraint')

		#get the clavicle (pelvis) joint's aim constraint
		aimCst = None
		for cst in aimCstList:
			if self._clavicleJoint in cst:
				aimCst = cst
				break

		#set the aim constraint's world up vector X to -1
		cmds.setAttr('{0}.worldUpVectorX'.format(aimCst),-1)


	def build(self):
		'''
		'''
		#run setup from parent class
		super(Leg,self).build()

		#get joints
		originalJoints = self._ikfkSystem.getOriginalJoints()
		blendJoints = self._ikfkSystem.getBlendJoints()
		ikJoints = self._ikfkSystem.getIkJoints()
		fkJoints = self._ikfkSystem.getFkJoints()
		ikfkGroup = self._ikfkSystem.getGroup()
		ikControlName = self._ikControl.getName()
		handle = self._ikfkSystem.getHandle()

		#unparent the ik handle
		cmds.parent(handle,w=True)

		#delete the parent constraint on the ik joint
		cmds.delete(cmds.listRelatives(ikJoints[-1],c=True,type='transform'))

		#set ikControl to 0,0,0 in world space
		cmds.setAttr('{0}.r'.format(ikControlName),0,0,0)

		#cmds.orientConstraint(ikControlName,ikJoints[-1],mo=True) #can't get this to work 
		cmds.parentConstraint(ikControlName,ikJoints[-1],mo=True,skipTranslate=['x','y','z'])
		cmds.parent(handle,ikControlName)
		cmds.setAttr('{0}.v'.format(handle),0)	

