'''
'''
#Import maya modules
import maya.cmds as cmds

#Import package modules
import rigtools.parts.part as rigPart
import rigtools.libs.joint as rigJoint
import rigtools.libs.name as rigName
import rigtools.libs.ikfk as rigIkFk
import rigtools.libs.attribute as rigAttr
import rigtools.libs.control as rigControl


class Limb(rigPart.Part):
	def __init__(self,name):
		super(Limb,self).__init__(name)
		
		#Class variables

		side = self._side

		self._startJoint = '{0}_upLimb_{1}'.format(side,rigName.JOINT)
		self._middleJoint = '{0}_midLimb_{1}'.format(side,rigName.JOINT)
		self._endJoint = '{0}_endLimb_{1}'.format(side,rigName.JOINT)
		self._positions = [(0,0,0),(5,0,-2),(10,0,0)]
		
		if side == rigName.LEFT:
			self._positions = [(2,0,0),(7,0,-2),(12,0,0)]
		elif side == rigName.RIGHT:
			self._positions = [(-2,0,0),(-7,0,-2),(-12,0,0)]


	def setPositions(self,value):
		'''
		'''
		self._positions = value

	def getPositions(self):
		'''
		'''
		positions = list()
		if cmds.objExists(self._startJoint):
			for jnt in [self._startJoint,self._middleJoint,self._endJoint]:
				positions.append(cmds.xform(jnt,q=True,ws=True,t=True))

			return positions

		return self._positions


	def setup(self):
		super(Limb,self).setup()

		parent = self._skeletonGroup
		guides = []

		self._masterGuide.setPosition(self._positions[0])

		#Create up and aim axis attributes on the masterGuide
		if rigName.getSide(self._name) == rigName.LEFT:
			upAxisAttr = rigAttr.switch('upAxis',self._masterGuide.getName(),value=1,
				choices = ['x','y','z','-x','-y','-z'], outputs = [(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)])
			aimAxisAttr = rigAttr.switch('aimAxis',self._masterGuide.getName(),value=0,
				choices = ['x','y','z','-x','-y','-z'], outputs = [(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(0,0,-1)])

		if rigName.getSide(self._name) == rigName.RIGHT:
			upAxisAttr = rigAttr.switch('upAxis',self._masterGuide.getName(),value=4,
				choices = ['x','y','z','-x','-y','-z'], outputs = [(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,1,0),(0,0,-1)])
			aimAxisAttr = rigAttr.switch('aimAxis',self._masterGuide.getName(),value=0,
				choices = ['x','y','z','-x','-y','-z'], outputs = [(1,0,0),(0,1,0),(0,0,1),(-1,0,0),(0,1,0),(0,0,-1)])
		

		for i,jnt in enumerate([self._startJoint,self._middleJoint,self._endJoint]):
			if not cmds.objExists(jnt):
				rigJoint.createJoint(jnt,position=self._positions[i],parent=parent)
				guide = self.createGuide('{0}_{1}'.format(jnt,rigName.GUIDE),jnt,color=self._color)
			else:
				if not cmds.objExists('{0}_{1}'.format(jnt,rigName.GUIDE)):
					guide = self.createGuide('{0}_{1}'.format(jnt,rigName.GUIDE),jnt,color=self._color)

			guides.append(guide)
			parent = jnt

		cmds.select(self._masterGuide.getName())
		
		startGuideName = guides[0].getName()
		middleGuideName = guides[1].getName()
		endGuideName = guides[2].getName()

		#Create Decompose Matrix nodes
		startDcomp = cmds.createNode('decomposeMatrix',n='{0}_{1}'.format(startGuideName,rigName.DECOMPOSEMATRIX))
		middleDcomp = cmds.createNode('decomposeMatrix',n='{0}_{1}'.format(middleGuideName,rigName.DECOMPOSEMATRIX))
		endDcomp = cmds.createNode('decomposeMatrix',n='{0}_{1}'.format(endGuideName,rigName.DECOMPOSEMATRIX))

		#Connect Decompose Matrix nodes
		cmds.connectAttr('{0}.worldMatrix'.format(startGuideName),'{0}.inputMatrix'.format(startDcomp),f=True)
		cmds.connectAttr('{0}.worldMatrix'.format(middleGuideName),'{0}.inputMatrix'.format(middleDcomp),f=True)
		cmds.connectAttr('{0}.worldMatrix'.format(endGuideName),'{0}.inputMatrix'.format(endDcomp),f=True)

		#Create Plus Minus Average nodes and set operation to subtract
		pma1 = cmds.createNode('plusMinusAverage',n='{0}_{1}'.format(startGuideName,rigName.PLUSMINUSAVERAGE))
		cmds.setAttr('{0}.operation'.format(pma1),2)
		pma2 = cmds.createNode('plusMinusAverage',n='{0}_{1}'.format(endGuideName,rigName.PLUSMINUSAVERAGE))
		cmds.setAttr('{0}.operation'.format(pma2),2)

		#Connect Decompose Matrix nodes to Plus Minus Average nodes
		cmds.connectAttr('{0}.outputTranslate'.format(startDcomp),'{0}.input3D[0]'.format(pma1),f=True)
		cmds.connectAttr('{0}.outputTranslate'.format(middleDcomp),'{0}.input3D[1]'.format(pma1),f=True)

		cmds.connectAttr('{0}.outputTranslate'.format(endDcomp),'{0}.input3D[0]'.format(pma2),f=True)
		cmds.connectAttr('{0}.outputTranslate'.format(startDcomp),'{0}.input3D[1]'.format(pma2),f=True)

		#Create Vector Product node, set operation to cross product and normalize output
		vectorProduct = cmds.createNode('vectorProduct',n='{0}_{1}'.format(self.getName(),rigName.VECTORPRODUCT))
		cmds.setAttr('{0}.operation'.format(vectorProduct),2)
		cmds.setAttr('{0}.normalizeOutput'.format(vectorProduct),1)

		#Connect Plus Minus Average nodes to Vector Product node
		cmds.connectAttr('{0}.output3D'.format(pma1),'{0}.input1'.format(vectorProduct))
		cmds.connectAttr('{0}.output3D'.format(pma2),'{0}.input2'.format(vectorProduct))

		#Aim constrain middleGuide to startJoint
		cst = cmds.aimConstraint(middleGuideName,self._startJoint,worldUpType='vector')[0]
		cmds.parent(cst,self._guidesGroup)
		cmds.connectAttr('{0}.output'.format(vectorProduct),'{0}.worldUpVector'.format(cst))
		cmds.connectAttr(aimAxisAttr, '{0}.aimVector'.format(cst), f=True)
		cmds.connectAttr(upAxisAttr, '{0}.upVector'.format(cst), f=True)

		#Aim constrain endGuide to middleJoint
		cst = cmds.aimConstraint(endGuideName,self._middleJoint,worldUpType='vector')[0]
		cmds.connectAttr('{0}.output'.format(vectorProduct),'{0}.worldUpVector'.format(cst))
		cmds.parent(cst,self._guidesGroup)
		cmds.connectAttr(aimAxisAttr, '{0}.aimVector'.format(cst), f=True)
		cmds.connectAttr(upAxisAttr, '{0}.upVector'.format(cst), f=True)

		#Orient constrain middleJoint to endJoint
		cst = cmds.orientConstraint(self._middleJoint,self._endJoint)[0]
		cmds.parent(cst,self._guidesGroup)

		#store aim and up axis attributes as class attributes for use in arm.py
		self._aimAxisAttr = aimAxisAttr
		self._upAxisAttr = upAxisAttr


	def build(self):
		'''
		builds ikfk limb
		'''
		#store first value of aim and up axis attributes and then delete them
		self._aimAxis = cmds.getAttr(self._aimAxisAttr)[0]
		self._upAxis = cmds.getAttr(self._upAxisAttr)[0]
		del(self._aimAxisAttr)
		del(self._upAxisAttr)

		#run build from parent class
		super(Limb,self).build()

	#----------IKFK SYSTEM----------
		#check that joints exist
		for joint in [self._startJoint,self._middleJoint,self._endJoint]:
			if not cmds.objExists(joint):
				raise RuntimeError('{0} does not exist in the scene'.format(joint))

		self._ikfkSystem = rigIkFk.IkFkLimb([self._startJoint,self._middleJoint,self._endJoint])

		#create ikfk system
		self._ikfkSystem.create()

		self._ikfkSystem.setGroupName('{0}_ikfk'.format(self._name))
		
		#get joints
		originalJoints = self._ikfkSystem.getOriginalJoints()
		blendJoints = self._ikfkSystem.getBlendJoints()
		ikJoints = self._ikfkSystem.getIkJoints()
		fkJoints = self._ikfkSystem.getFkJoints()
		
		#parent ikfk group to controls group
		ikfkGroup = self._ikfkSystem.getGroup()
		cmds.parent(ikfkGroup,self._controlsGroup)

		#create pole vector control and constraint
		poleVectorControl = rigControl.Control('{0}_{1}'.format(self._name,rigName.POLEVECTOR),
														parent = self._controlsGroup,
														shape = 'sphere',
														color = self._color,
														position = self._ikfkSystem.getPoleVectorPosition(ikJoints))

		poleVectorControl.create()
		cmds.poleVectorConstraint(poleVectorControl.getName(),self._ikfkSystem.getHandle())

	#----------TWIST JOINT----------
		#duplicate the original end joint to create the twist joint
		#aim constrain twist joint to ???


	#----------PARAMNODE----------
		#create a parameter node (a locator's shape node)
		nameSplit = self._name.split(rigName.DELIMITER)
		side = self.getSide(self._name)
		if len(side) > 1:
			for name in side.split('_'):
				nameSplit.remove(name)

		paramNode = cmds.createNode('locator',n='{0}_{1}'.format('_'.join(nameSplit),side.title()))
		
		#parent the paramNode's shape to the pole vector control and delete the leftover empty node
		paramParent = cmds.listRelatives(paramNode,p=True)
		cmds.parent(paramNode,poleVectorControl.getName(),r=True,s=True)
		cmds.delete(paramParent)

		#lock and hide shape attributes
		for attr in ('lpx','lpy','lpz','lsx','lsy','lsz'):
			rigAttr.lockAndHideAttr(paramNode,attr)

		#turn off visibility
		cmds.setAttr('{0}.visibility'.format(paramNode),0)

		#add ikfk switch attribute to parameter node and connect it to the ikfk switch attribute on the ikfk group
		cmds.addAttr(paramNode,ln='ikfk',at='double',min=0,max=1,dv=0,keyable=True)
		ikfkAttribute = '{0}.{1}'.format(paramNode,'ikfk')
		cmds.connectAttr(ikfkAttribute, '{0}.ikfk'.format(ikfkGroup),f=True)

		self._paramNode = paramNode


	#----------IK CONTROLS----------
		#create ik controls
		ikControl = rigControl.Control('{0}_{1}'.format(ikJoints[-1].replace('{0}'.format(rigName.JOINT),''),rigName.CONTROL),
														parent = self._controlsGroup,
														shape = 'sphere',
														color = self._color,
														position = cmds.xform(ikJoints[-1],q=True,ws=True,t=True))

		ikControl.create()

		#parent, position, and constrain the ik control
		handle = self._ikfkSystem.getHandle()
		ikControlName = ikControl.getName()
		self._ikControl = ikControl

		endIkJntRot = cmds.xform(ikJoints[-1],q=True,ws=True,ro=True)
		cmds.xform(ikControlName,ws=True,ro=endIkJntRot)	#adds rotation to the control that can be used for an animation start pose	
		
		#set ik control's rotation to match ik end joint
		aimJoint = cmds.duplicate(ikJoints[-1],po=True,rr=True,name='aimJoint')[0]
		upJoint = cmds.duplicate(ikJoints[-1],po=True,rr=True,name='upJoint')[0]

		if rigName.getSide(self._name) == rigName.LEFT:
			cmds.xform(aimJoint,r=True,t=self._aimAxis)
			cmds.xform(upJoint,r=True,t=self._upAxis)
		elif rigName.getSide(self._name) == rigName.RIGHT:
			cmds.xform(aimJoint,r=True,t=[self._aimAxis[0]*-1,self._aimAxis[1]*-1,self._aimAxis[2]*-1])
			cmds.xform(upJoint,r=True,t=[self._upAxis[0]*-1,self._upAxis[1]*-1,self._upAxis[2]*-1])

		cmds.delete([cmds.aimConstraint(aimJoint,ikControlName,
										aimVector = [1,0,0],
										upVector = [0,1,0],
										worldUpType = 'object',
										worldUpVector = [0,1,0],
										worldUpObject = upJoint)[0],upJoint,aimJoint])

		#cmds.orientConstraint(ikControlName,ikJoints[-1],mo=True) #can't get this to work 
		cmds.parentConstraint(ikControlName,ikJoints[-1],mo=True,skipTranslate=['x','y','z'])
		cmds.parent(handle,ikControlName)
		cmds.setAttr('{0}.v'.format(handle),0)		

		#add the paramNode to the ik control
		cmds.parent(paramNode,ikControlName,r=True,s=True,add=True)

	#----------VISIBILITY----------
		#create and connect reverse node for control visibility
		reverseNode = cmds.createNode('reverse',n='{0}_{1}'.format(self._name,rigName.REVERSE))
		cmds.connectAttr(ikfkAttribute,'{0}.inputX'.format(reverseNode),f=True)
		for ctrl in (ikControlName,poleVectorControl.getName()):
			for shape in rigControl.Control.getShapes(ctrl):
				if shape != paramNode:
					cmds.connectAttr('{0}.outputX'.format(reverseNode),'{0}.v'.format(shape),f=True)

	#----------FK CONTROLS----------
		#
		fkControls = list()
		#add an attribute to the paramNode to store the fkControls
		cmds.addAttr(paramNode,ln='fkControls',dt='string')
		fkControlsStr = str()

		parent = self._controlsGroup
		for i in range(len(originalJoints)):
			cmds.parentConstraint(blendJoints[i],originalJoints[i])
			
			#create and position fk controls
			fkControlName = '{0}_{1}'.format(fkJoints[i].replace('_{0}'.format(rigName.JOINT),''),rigName.CONTROL)
			fkControl = rigControl.Control.createControl(name=fkControlName,parent=parent,shape='circle',color=self._color)
			fkControl.setPosition(cmds.xform(fkJoints[i],q=True,ws=True,t=True))
			fkControl.setRotate(cmds.xform(fkJoints[i],q=True,ws=True,ro=True))
			fkControl.setRotateOrder(cmds.xform(fkJoints[i],q=True,roo=True))
			cmds.pointConstraint(fkControl.getName(),fkJoints[i])
			cmds.orientConstraint(fkControl.getName(),fkJoints[i])
			
			cmds.parent(paramNode,fkControl.getName(),r=True,s=True,add=True)
			parent = fkControl.getName()

			#connect paramNode to visibility
			for shape in rigControl.Control.getShapes(fkControl.getName()):
				if shape != paramNode:
					cmds.connectAttr(ikfkAttribute,'{0}.v'.format(shape),f=True)

			#store fkControls for use later
			fkControlsStr = fkControlsStr + ' ' + fkControl.getName()
			fkControls.append(fkControl)

		#set the fkControls on the fkControls attribute on the paramNode
		cmds.setAttr('{0}.fkControls'.format(paramNode),fkControlsStr,type='string')

	#----------TWIST JOINT----------
		#duplicate the original start joint to create the twist joint
		originalJoints = self._ikfkSystem.getOriginalJoints()
		twistJoint = cmds.duplicate(originalJoints[-1],n='{0}.twist_{1}'.format(self._name,rigName.JOINT),rr=True,po=True)

		#aim constrain twist joint to original elbow joint
		cmds.aimConstraint(originalJoints[-2],
									twistJoint,
									worldUpType='none',
									u=self._upAxis,
									aim=(self._aimAxis[0]*-1,
										self._aimAxis[1]*-1,
										self._aimAxis[2]*-1))


	def postBuild(self):
		'''
		Cleans up build method
		'''
		super(Limb,self).postBuild()

		#turn off visibility of ik, fk, and blend joints
		ikfkGroup = self._ikfkSystem.getGroup()
		cmds.setAttr('{0}.v'.format(ikfkGroup),0)

		#delete unused attributes from build
		del(self._aimAxis)
		del(self._upAxis)
		del(self._ikControl)