'''
Template for biped builds
'''
import maya.cmds as cmds
import maya.OpenMaya as om
import rigtools.templates.rig as rig
reload(rig)
import rigtools.libs.control as rigControl
reload(rigControl)
import rigtools.parts.part as part

import rigtools.parts.arm as arm
reload(arm)
import rigtools.parts.leg as leg
reload(leg)
import rigtools.parts.foot as foot
reload(foot)
import rigtools.libs.name as rigName

#create a reload order tag in place of reloading each import
#__reload__ = ()

class Biped(rig.Rig):
	'''
	'''
	def __init__(self,name):
		'''
		Constructor method for biped template class

		Parameters:
		name (str) = name of the element being built
		'''

		super(Biped,self).__init__(name)

		#register left parts
		self.registerPart('Left_Leg',leg.Leg('l_leg'))
		self.registerPart('Left_Foot',foot.Foot('l_foot'),'Left_Leg')
		self.registerPart('Left_Arm',arm.Arm('l_arm'))

		#register right parts
		self.registerPart('Right_Leg',leg.Leg('r_leg'))
		self.registerPart('Right_Foot',foot.Foot('r_foot'),'Right_Leg')
		self.registerPart('Right_Arm',arm.Arm('r_arm'))

		#define hip sway joints
		self._rootJoint = 'root_{0}'.format(rigName.JOINT)
		self._hipSwayJoint = 'hipSway_{0}'.format(rigName.JOINT)

	def setup(self):
		'''
		Base setup method
		'''
		super(Biped,self).setup()

		#get center position between left and right pelvis
		leftPelvisPos = self._graph.getPart('Left_Leg').getPositions()[0]
		rightPelvisPos = self._graph.getPart('Right_Leg').getPositions()[0]
		leftPelvisPnt = om.MVector(*leftPelvisPos)
		rightPelvisPnt = om.MVector(*rightPelvisPos)
		rootPnt = (leftPelvisPnt + rightPelvisPnt) / 2

		#create the hip sway joints
		rootJoint = cmds.joint(name=self._rootJoint,position=(rootPnt.x,rootPnt.y+1,rootPnt.z))
		hipSwayJoint = cmds.joint(name=self._hipSwayJoint,position=(rootPnt.x,rootPnt.y,rootPnt.z))
		cmds.parent(rootJoint,part.Part.puppetNode)
		#cmds.parent(hipSwayJoint,rootJoint)

		#create guides for the hip sway joints
		rootGuide = rigControl.Guide.createGuide('root_{0}'.format(rigName.GUIDE),part.Part.puppetNode,'square',4)
		hipSwayGuide = rigControl.Guide.createGuide('hipSway_{0}'.format(rigName.GUIDE),rootGuide.getName(),'sphere',17)

		for joint,guide in zip([rootJoint,hipSwayJoint],[rootGuide,hipSwayGuide]):
			trs = cmds.xform(joint,q=True,ws=True,rp=True)
			guide.setPosition(trs)
			cst = cmds.pointConstraint(guide.getName(),joint)

	def build(self):
		'''
		Base build method
		'''
		cmds.parent(self._rootJoint,w=True)
		super(Biped,self).build()
		cmds.parent(self._rootJoint,self._bindGroup)

		#connect legs to hip sway joint
		cmds.parent([self._graph.getPart('Left_Leg')._clavicleJoint,
					self._graph.getPart('Right_Leg')._clavicleJoint],
					self._hipSwayJoint)

		#connect arms to spine (no spine yet- parent to hip sway joint for now)
		cmds.parent([self._graph.getPart('Left_Arm')._clavicleJoint,
					self._graph.getPart('Right_Arm')._clavicleJoint],
					self._hipSwayJoint)

		#connect feet to legs
		cmds.parent(self._graph.getPart('Left_Foot')._footJoint,self._graph.getPart('Left_Leg')._endJoint)
		cmds.parent(self._graph.getPart('Right_Foot')._footJoint,self._graph.getPart('Right_Leg')._endJoint)

		cmds.setAttr('l_ankle__ik_CTL_NULL.v',0)	
		cmds.parent('l_leg_L','l_foot__ik_CTL',r=True,shape=True,add=True)
		for attr in cmds.listConnections('l_foot_L',plugs=True):
			cmds.connectAttr('l_leg_L.ikfk',attr,f=True)
		cmds.delete('l_foot_L')
		cmds.parent('l_ankle__ik_CTL_NULL','l_foot_ankleDriver')

		cmds.setAttr('r_ankle__ik_CTL_NULL.v',0)	
		cmds.parent('r_leg_R','r_foot__ik_CTL',r=True,shape=True,add=True)
		for attr in cmds.listConnections('r_foot_R',plugs=True):
			cmds.connectAttr('r_leg_R.ikfk',attr,f=True)
		cmds.delete('r_foot_R')
		cmds.parent('r_ankle__ik_CTL_NULL','r_foot_ankleDriver')		


