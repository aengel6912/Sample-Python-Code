'''
Base template class for building a rig
'''
import maya.cmds as cmds
import rigtools.libs.graph as graph
reload(graph)

class Rig(object):
	'''
	'''
	def __init__(self,name):
		'''
		Constructor method for base template class

		Parameters:
		name (str) = name of the element being built
		'''

		#define class variables
		self._name = name
		self._graph = graph.Graph('rigBuild')
		self._trsMaster = 'master_trs'
		self._trsShot = 'shot_trs'
		self._trsAux = 'aux_trs'
		self._bindGroup = 'bind'
		self._rigGroup = 'rig'
		self._noXformGroup = 'noXform'

	def registerPart(self,name,part,parent=None):
		'''
		'''
		self._graph.addPart(name,part,parent)



	def getName(self):
		'''
		Gets name passed-in during initialization
		'''
		return self._name


	def setName(self,value):
		'''
		Sets name to a passed-in value
		'''
		self._name = value

	@staticmethod
	def newScene(self):
		'''
		create a new new scene
		'''
		cmds.file(new=True,f=True)

	def setup(self):
		'''
		Base setup method
		'''
		for part in self._graph.getBuildOrder():
			part.runSetup()


	def build(self):
		'''
		Base build method
		'''

		#create the hierarchy
		for name in [self._name,self._trsMaster,self._trsShot,self._trsAux,self._rigGroup,self._bindGroup,self._noXformGroup]:
			if not cmds.objExists(name):
				cmds.createNode('transform',name=name)

		#parent the hierarchy
		cmds.parent(self._trsMaster,self._name)
		cmds.parent(self._trsShot,self._trsMaster)
		cmds.parent(self._trsAux,self._trsShot)
		cmds.parent(self._rigGroup,self._trsAux)
		cmds.parent(self._bindGroup,self._rigGroup)
		cmds.parent(self._noXformGroup,self._rigGroup)	

		#turn on display handle for master and shot group
		for grp in (self._trsMaster,self._trsShot):
			cmds.setAttr('{0}.displayHandle'.format(grp),1)

		#run the build
		for part in self._graph.getBuildOrder():
			part.runBuild()

			children = cmds.listRelatives(part._jointsGroup,c=True) or list()

			#move joints to the bind group
			children = cmds.listRelatives(part._jointsGroup,c=True) or list()			
			for child in children:
				cmds.parent(child,self._bindGroup)

			#move noXform children to the noXformGroup
			children = cmds.listRelatives(part._noXformGroup,c=True) or list()			
			for child in children:
				cmds.parent(child,self._noXformGroup)

			#move controls to the rig group
			children = cmds.listRelatives(part._controlsGroup,c=True) or list()				
			for child in children:
				cmds.parent(child,self._rigGroup)

			#delete parts
			cmds.delete(part._rigGroup)

		cmds.delete(part.puppetNode)
