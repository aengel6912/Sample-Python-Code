'''
Joint module
Creates a joint
'''

#Import maya modules
import maya.cmds as cmds

def createJoint(name,position=[0,0,0],parent=None):
	'''
	This function creates a joint

	Example:
		createJoint('joint1')
		creates an unparented joint called joint1 at the origin

	Parameters:
		name (str) = name of your joint
		position (list) = x,y,z coordinates of your joint (default is origin)
		parent (str) = parent of your joint (default is no parent)

	Return:
		rerurns name of joint created
	'''

	#Check that joint name is a string
	if not isinstance(name,basestring):
		raise TypeError('{0} must be a string'.format(name))

	#Store current selection
	sel = cmds.ls(sl=True)

	#Clear current selection
	cmds.select(clear=True)

	#Create joint
	jnt = cmds.joint(n=name,p=position)

	#Parent the joint if parent was passed in
	if parent:
		cmds.parent(jnt,parent)

	#Restore original selection
	cmds.select(sel)

	return jnt


def orientToRotate(jnt):
	'''
	'''
	#get rotation values
	orient = cmds.xform(jnt,q=True,ws=True,ro=True)

	#set joint orient to zero
	cmds.setAttr(jnt+'.jo',0,0,0)

	#put info into rotate channel
	cmds.xform(jnt,ws=True,ro=orient)


def rotateToOrient(jnt):
	'''
	'''

	#Store rotation order and then set it to 'xyz'
	rotOrder = cmds.xform(jnt,q=True,roo=True)
	cmds.xform(jnt,p=True,roo='xyz')

	#Run orientToRotate to put rotation values in rotate channels
	orientToRotate(jnt)

	#Store rotation value
	orient = cmds.getAttr(jnt+'.r')[0]

	#Put rotation value into the joint orient
	cmds.setAttr('{0}.jo'.format(jnt), *orient)
	
	#Set rotate values to zero
	cmds.setAttr('{0}.r'.format(jnt),0,0,0)
	
	#Return rotation order to original
	cmds.xform(jnt,p=True,roo=rotOrder)
