'''
createJointChain module
'''

#Import maya modules
import maya.cmds as cmds

def createJointChain(numOfJoints,suffix="_JNT"):
    '''
    This function creates a joint chain in the Y axis
    
    Example:
        createJointChain(6) creates a chain of 6 joints
    
    Parameters:
        numOfJoints (int) = number of joints in the chain
        suffix (str) = suffix for your joints (default is _JNT)
        
    Return:
        jointList = a list of joints created
    '''
   
    #clear selection
    cmds.select(clear=True)
    
    #check that numOfJoints is int
    if not isinstance(numOfJoints,int):
        raise TypeError('"'+numOfJoints+'"' + " must be an int")
      
    #define jointList variable
    jointList = list()
    
    #create and name joints and append to jointList
    for i in range(numOfJoints):
        jnt = cmds.joint(n='joint%s' % str(i+1)+suffix, position=[0,i*2,0])
        jointList.append('joint%s' % str(i+1)+suffix)
    
    #select first joint in chain
    cmds.select(jointList[0])
    
    return jointList