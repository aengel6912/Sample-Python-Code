'''
IkFk Module
'''

#Import maya modules
import maya.cmds as cmds
import maya.OpenMaya as om

#Import package modules
import rigtools.libs.joint as rigJoint
import rigtools.libs.name as rigName
import rigtools.libs.mayaObject as rigMayaObject
reload(rigMayaObject)

#import just the MayaObject class from mayaObject.py
from rigtools.libs.mayaObject import MayaObject


class IkFkBase(object):
	'''
	base class for all ikfk objects
	'''

	#CONSTRUCTOR method
	def __init__(self,joints):
		'''
		Parameters:
		joints (list or tuple) = joints in the scene that will be used to create an ikfk system
		'''

		#Construct variables and set types
		self._originalJoints = list()
		self._ikJoints = list()
		self._fkJoints = list()
		self._blendJoints = list()
		self._group = 'ikfk'
		self._handle = str()

		self.setOriginalJoints(joints)

		
	def getOriginalJoints(self):
		'''
		return the original joints passed in
		'''
		return self._originalJoints


	def setOriginalJoints(self,value):
		'''
		set the original joints that will be used to create the joint chains

		Parameters:
		value (list or tuple) = joints that exist in the scene
		'''

		#Check for errors
		if not isinstance(value,(list, tuple)):
			raise TypeError ("{0} must be a list or tuple".format(value))

		for obj in value:
			if not cmds.objExists(obj):
				raise RuntimeError("{0} does not exist".format(obj))
			elif cmds.nodeType(obj) !="joint":
				raise RuntimeError("{0} is not a joint".format(obj))

		self._originalJoints = value	


	def getGroup(self):
		'''
		'''
		return self._group


	def getFkJoints(self):
		'''
		'''
		return self._fkJoints


	def getIkJoints(self):
		'''
		'''
		return self._ikJoints


	def getBlendJoints(self):
		'''
		'''
		return self._blendJoints


	def getHandle(self):
		'''
		'''
		return self._handle


	def setGroupName(self,value):
		'''
		'''
		#Check for errors and rename the group
		if not isinstance(value,basestring):
			raise TypeError ("{0} must be a string".format(value))

		if self._group and cmds.objExists(self._group):
			cmds.rename(self._group,value)
			self._group = value


	def setGroup(self,value):
		'''
		'''
		if not isinstance(value,basestring):
			raise TypeError('{0} must be a string'.format(value))

		if self._ikJoints and cmds.objExists(self._ikJoints[0]):
			ikParent = cmds.listRelatives(self._ikJoints[0],p=True)
			if ikParent:
				if value != ikParent[0]:
					self.setGroupName(value)
				elif cmds.objExists(self._group):
					self.setGroupName(value)
					cmds.parent([self._ikJoints[0],self._fkJoints[0],self._blendJoints[0]],value)
				else:
					cmds.createNode('transform',n=value)
					self._group = value
					attrs = self._createGroupAttrs()
					ikfkAttr = attrs['ikfk']
					cmds.parent([self._ikJoints[0],self._fkJoints[0],self._blendJoints[0]],value)

					#create and connect blend color nodes
					for i,jnt in enumerate(self._blendJoints):
						rot = '{0}_rot_BCN'.format(jnt)
						trs = '{0}_trs_BCN'.format(jnt)
						if cmds.objExists(trs) and cmds.objExists(rot):
							cmds.connectAttr(ikfkAttr,'{0}.blender'.format(rot),f=True)
							cmds.connectAttr(ikfkAttr,'{0}.blender'.format(trs),f=True)


	def setHandle(self,value):
		'''
		'''
		#Error checks
		if not isinstance(value,basestring):
			raise TypeError('{0} must be a string'.format(value))
		elif not cmds.objExists(value):
			raise RuntimeError('{0} does not exist in the scene'.format(value))
		elif not cmds.nodeType(value) == 'ikHandle':
			raise RuntimeError('{0} must be nodeType ikHandle'.format(value))

		self._handle = value


	def connect(self):
		'''
		'''
		pass


	def disconnect(self):
		'''
		'''
		pass


	def _createGroupAttrs(self):
		'''
		'''
		pass


	#CREATE method
	def create(self):
		
		#Group and custom attributes
		cmds.createNode("transform", n=self._group)
		cmds.addAttr(self._group,ln="ikfk",at="double",min=0,max=1,dv=0,keyable=True)
		ikfkAttr = "{0}.ikfk".format(self._group)

		#FK joints
		parent = self._group

		for jnt in self._originalJoints:
			cmds.select(cl=True)
			dupJnt = cmds.duplicate(jnt,rr=True,po=True,n="{0}_fk".format(jnt))[0]
			cmds.parent(dupJnt,parent)
			parent = dupJnt
			self._fkJoints.append(dupJnt)

		#IK joints
		parent = self._group

		for jnt in self._originalJoints:
			cmds.select(cl=True)
			dupJnt = cmds.duplicate(jnt,rr=True,po=True,n="{0}_ik".format(jnt))[0]
			cmds.parent(dupJnt,parent)
			parent = dupJnt
			self._ikJoints.append(dupJnt)

		#Blend joints
		parent = self._group

		for i,jnt in enumerate(self._originalJoints):
			cmds.select(cl=True)
			dupJnt = cmds.duplicate(jnt,rr=True,po=True,n="{0}_blend".format(jnt))[0]
			cmds.parent(dupJnt,parent)
			parent = dupJnt
			self._blendJoints.append(dupJnt)

			#Create blendColors nodes
			trs = cmds.createNode("blendColors",n="{0}_trs_bcn".format(dupJnt))
			rot = cmds.createNode("blendColors",n="{0}_rot_bcn".format(dupJnt))

			#Connect blendColors nodes
			cmds.connectAttr("{0}.t".format(self._fkJoints[i]),"{0}.color1".format(trs),f=True)
			cmds.connectAttr("{0}.t".format(self._ikJoints[i]),"{0}.color2".format(trs),f=True)

			cmds.connectAttr("{0}.r".format(self._fkJoints[i]),"{0}.color1".format(rot),f=True)
			cmds.connectAttr("{0}.r".format(self._ikJoints[i]),"{0}.color2".format(rot),f=True)

			cmds.connectAttr(ikfkAttr,"{0}.blender".format(trs),f=True)
			cmds.connectAttr(ikfkAttr,"{0}.blender".format(rot),f=True)

			cmds.connectAttr("{0}.output".format(trs),"{0}.t".format(dupJnt),f=True)
			cmds.connectAttr("{0}.output".format(rot),"{0}.r".format(dupJnt),f=True)



class IkFkLimb(IkFkBase):
	def __init__(self,joints):
		'''
		constructor method
		'''
		super(IkFkLimb,self).__init__(joints)

		self._poleVector = str()


	@staticmethod
	def getPoleVectorPosition(joints,multiply = 3):
		'''
		'''
		#check that joints is a list of 3 joints
		pass

		#define joints
		startJnt = joints[0]
		middleJnt = joints[1]
		endJnt = joints[2]

		#get joint positions in worldspace
		startPnt = cmds.xform(startJnt,query=True,worldSpace=True,t=True)
		middlePnt = cmds.xform(middleJnt,query=True,worldSpace=True,t=True)
		endPnt = cmds.xform(endJnt,query=True,worldSpace=True,t=True)

		#draw vectors using Open Maya
		startVector = om.MVector(*startPnt)
		middleVector = om.MVector(*middlePnt)
		endVector = om.MVector(*endPnt)

		#find mid-point between start and end vectors
		startEndVector = (startVector + endVector) / 2

		#extend mid-point backwards by value of multipy
		pvDiffVector = (middleVector - startEndVector) * multiply

		#define pole vector
		poleVector = pvDiffVector + startEndVector

		#return XYZ values of the pole vector
		return poleVector.x, poleVector.y, poleVector.z


	def getPoleVector(self):
		'''
		'''
		return self._poleVector


	def setOriginalJoints(self,value):
		'''
		'''
		if len(value) != 3:
			raise RuntimeError('{0} must 3 joints'.format(value))

		super(IkFkLimb,self).setOriginalJoints(value)


	def create(self):
		#call create method from IkFkBase class
		super(IkFkLimb,self).create()

		#create the ik handle
		self.setHandle(cmds.ikHandle(startJoint=self._ikJoints[0],
										endEffector=self._ikJoints[-1],
										solver='ikRPsolver',
										name='{0}_{1}'.format(self._ikJoints[-1],rigName.HANDLE))[0])

		#parent handle to the group
		cmds.parent(self._handle,self._group)



class IkFkFoot(IkFkBase):
	def __init__(self,joints):
		'''
		constructor method
		'''
		super(IkFkFoot,self).__init__(joints)

		#Get default positions for foot roll groups
		footPosition = cmds.xform(joints[0],q=True,ws=True,t=True)
		bankInPosition = cmds.xform(joints[1],q=True,ws=True,t=True)
		bankInPosition[0] = bankInPosition[0] - 2
		bankOutPosition = cmds.xform(joints[1],q=True,ws=True,t=True)
		bankOutPosition[0] = bankOutPosition[0] + 2
		heelPivotPosition = [footPosition[0],0,footPosition[2]]
		heelRollPosition = [footPosition[0],0,footPosition[2]]
		ballPivotPosition = cmds.xform(joints[1],q=True,ws=True,t=True)
		toePivotPosition = cmds.xform(joints[2],q=True,ws=True,t=True)
		toeRollPosition = toePivotPosition
		toeBendPosition = ballPivotPosition
		ballRollPosition = ballPivotPosition

		#Create the foot roll groups
		self._footRollGroups = [MayaObject('footRoll_{0}'.format(rigName.GROUP),self._group,footPosition),
								MayaObject('bankIn_{0}'.format(rigName.GROUP),'footRoll_{0}'.format(rigName.GROUP),bankInPosition),
								MayaObject('bankOut_{0}'.format(rigName.GROUP),'bankIn_{0}'.format(rigName.GROUP),bankOutPosition),
								MayaObject('heelPivot_{0}'.format(rigName.GROUP),'bankOut_{0}'.format(rigName.GROUP),heelPivotPosition),
								MayaObject('heelRoll_{0}'.format(rigName.GROUP),'heelPivot_{0}'.format(rigName.GROUP),heelRollPosition),
								MayaObject('ballPivot_{0}'.format(rigName.GROUP),'heelRoll_{0}'.format(rigName.GROUP),ballPivotPosition),
								MayaObject('toePivot_{0}'.format(rigName.GROUP),'ballPivot_{0}'.format(rigName.GROUP),toePivotPosition),
								MayaObject('toeRoll_{0}'.format(rigName.GROUP),'toePivot_{0}'.format(rigName.GROUP),toeRollPosition),
								MayaObject('toeBend_{0}'.format(rigName.GROUP),'toeRoll_{0}'.format(rigName.GROUP),toeBendPosition),
								MayaObject('ballRoll_{0}'.format(rigName.GROUP),'toeRoll_{0}'.format(rigName.GROUP),ballRollPosition),
								]

		self._handle = list()
		self._ankleDriver = 'ankleDriver_{0}'.format(rigName.GROUP)

	#----------GETS-----------
	def getFootGroupNames(self):
		'''
		'''
		return [group.getName() for group in self._footRollGroups]

	def getFootGroups(self):
		'''
		'''
		return self._footRollGroups

	def getAnkleDriver(self):
		'''
		'''
		return self._ankleDriver	

	#----------SETS-----------
	def setGroupParent(self,name,parent):
		'''
		'''
		groupNames = self.getFootGroupNames()
		for grpName in groupNames:
			if name == grpName:
				index = groupNames.index(grpName)
				self_footRollGroups[index].setParent(parent)

	def setHandle(self,value):
		'''
		overrides IkFkBase setHandle function
		'''
		#Error checks
		if not isinstance(value,(list,tuple)):
			raise TypeError('{0} must be a list or tuple'.format(value))

		self._handle = value

	def setFootGroups(self,value):
		'''
		'''
		#check that footRollGroup is an instance of the MayaObject
		if not isinstance(value,(list,tuple)):
			raise TypeError('{0} must be a list or tuple of MayaObject instances'.format(value))
		elif not isinstance(value[0],MayaOjbect):
			raise TypeError('{0} must be a list or tuple of MayaObject instances'.format(value))	

		self._footRollGroups = value

	def setAnkleDriver(self,value):
		'''
		'''
		if not isinstance(value,basestring):
			raise TypeError('{0} must be a string'.format(value))

		if cmds.objExists(self._ankleDriver):
			cmds.rename(self._ankleDriver,value)

		self._ankleDriver = value

	def addFootGroup(self,name,parent=None):
		'''
		adds a new member to the footRollsGroup
		'''
		self_footRollGroups.append(MayaObject('{0}_{1}'.format(name,rigName.GROUP),parent))

	def positionPivot(self,group,position=(0,0,0),relative=False):
		'''
		moves pivots of footRollGroups to their correct location
		'''
		footRollGroupNames = self.getFootGroupNames()

		if group in footRollGroupNames:
			grpName = group
		else:
			raise RuntimeError('{0} does not exist'.format(group))

		if cmds.objExists(grpName) and not relative:
			cmds.xform(grpName,ws=True,t=position)
		elif cmds.objExists and relative:
			cmds.xform(grpName,relative=True,t=position)

	def createGroups(self):
		'''	
		creates the footRollGroups
		'''
		#create the footRollGroups and hierarchy
		for group in self._footRollGroups:
			grpName = group.getName()		
			grpParent = group.getParent()
			if cmds.objExists(grpName):
				continue

			cmds.createNode('transform',name=grpName)
			cmds.xform(grpName,ws=True,t=group.getPosition())
			children = cmds.listRelatives(grpParent,c=True) or list()
			if grpParent:
				if cmds.objExists(grpParent) and not grpName in children:
					cmds.parent(grpName,grpParent)


	def create(self):
		'''
		'''
		#run create from the parent class
		super(IkFkFoot,self).create()

		self.createGroups()

		#create the ball ik handle
		ballHandle = cmds.ikHandle(startJoint=self._ikJoints[0],
					endEffector=self._ikJoints[1],
					solver='ikSCsolver',
					name='{0}_{1}'.format(self._ikJoints[1],rigName.HANDLE))[0]

		#create the toe ik handle
		toeHandle = cmds.ikHandle(startJoint=self._ikJoints[1],
					endEffector=self._ikJoints[2],
					solver='ikSCsolver',
					name='{0}_{1}'.format(self._ikJoints[2],rigName.HANDLE))[0]

		self.setHandle((ballHandle,toeHandle))

		#parent ik handles to the correct footRollGroups
		cmds.parent(toeHandle,self._footRollGroups[-2].getName())		
		cmds.parent(ballHandle,self._footRollGroups[-1].getName())

		#create an ankleDriver transform, parent it into the ballRoll group and parent constrain the ikJoints to it
		cmds.createNode('transform',n=self._ankleDriver)
		cmds.parent(self._ankleDriver,self._footRollGroups[-1].getName())
		cmds.parentConstraint(self._ankleDriver,self._ikJoints[0],mo=True)