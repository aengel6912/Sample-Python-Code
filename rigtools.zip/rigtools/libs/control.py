'''
Control module

'''

#Import maya modules
import maya.cmds as cmds

#Import package modules
import rigtools.libs.mayaObject as rigMayaObj
reload(rigMayaObj)
import rigtools.libs.name as rigName
reload(rigName)

class Control(rigMayaObj.MayaObject):
	def __init__(self,name,parent = str(),shape='circle',color = 0,position=(0,0,0)):
		super(Control,self).__init__(name)
		
		self._color = color
		self.setParent(parent)
		self._shape = shape
		self._position = position
	
	#GET

	def getNullGroup(self):
		'''
		'''
		if cmds.objExists(self._name):
			udAttrs = cmds.listAttr(self._name,ud=True) or list()
			if 'null' in udAttrs:
				connections = cmds.listConnections('{0}.null'.format(self._name)) or list()
				if connections:
					return connections[0]
		return None

	
	def getPosition(self):
		'''
		returns position of the guide
		'''
		return cmds.xform(self._name,q=True,ws=True,t=True)


	def getParent(self):
		'''
		'''
		nul = self.getNullGroup()
		if nul:
			relatives = cmds.listRelatives(self._name,p=True)
			if relatives:
				return relatives[0]

		return None

	#SET

	def setParent(self,value):
		'''
		'''
		if not isinstance(value,basestring):
			raise TypeError('{0} must be a string'.format(value))

		parent = self.getParent()

		if cmds.objExists(value) and parent != value:
			nul = self.getNullGroup()
			#if nul:
				#cmds.parent(nul,value)

		self._parent = value


	def setColor(self,value):
		'''
		'''
		if not isinstance(value,int):
			raise TypeError('{0} must be an int between 0-31'.format(value))

		if cmds.objExists(self._name):
			cmds.setAttr('{0}.overrideEnabled'.format(self._name),1)
			cmds.setAttr('{0}.overrideColor'.format(self._name),value)

		self._color = value


	def setPosition(self,value):
		'''
		Positions the control
		'''

		if not isinstance(value,(list,tuple)) or len(value) != 3:
			raise TypeError('{0} must be position with X,Y,Z values'.format(value))

		if cmds.objExists(self._name):
			nul = self.getNullGroup()
			cmds.xform(nul,ws=True,t=value)

		self._position = value


	def setRotate(self,value):
		'''
		'''
		if not isinstance(value,(list,tuple)) or len(value) != 3:
			raise TypeError('{0} must be position with X,Y,Z values'.format(value))

		if cmds.objExists(self._name):
			nul = self.getNullGroup()
			cmds.xform(nul,ws=True,ro=value)


	def setRotateOrder(self,value):
		'''
		'''
		if not isinstance(value,basestring) or len(value) != 3:
			raise TypeError('{0} must be a "XYZ" value'.format(value))

		if cmds.objExists(self._name):
			nul = self.getNullGroup()
			#set rotate order on the null
			cmds.xform(nul,roo=value)
			#set rotate order on the control as well
			cmds.xform(self._name,roo=value)

	#Create
	def create(self):
		'''
		'''
		if cmds.objExists(self._name):
			return

		if self._shape == 'sphere':
			guide = createSphere(self._name)
		elif self._shape == 'circle':
			guide = createCircle(self._name)
		else:
			guide = createCircle(self._name)

		nul = cmds.createNode('transform',n='{0}_{1}'.format(self._name,rigName.NULL))
		cmds.parent(guide,nul)

		cmds.addAttr(guide,ln='null',at='message')
		cmds.connectAttr('{0}.message'.format(nul),'{0}.null'.format(guide),f=True)

		if self._parent:
			cmds.parent(nul,self._parent)

		self.setColor(self._color)

		cmds.xform(nul,ws=True,t=self._position)

		return self._name


	@staticmethod
	def createControl(name,parent=str(),shape='circle',color=0):
		ctrl = Control(name,parent,shape,color)
		ctrl.create()

		return ctrl


	@staticmethod
	def scale(ctrl,scale=[1,1,1]):
		'''
		'''
		shapes = Control.getShapes(ctrl)

		#Scale a nurbs curve
		if Control.getType(ctrl) == 'nurbsCurve':
			for shape in shapes:
				cmds.scale(scale[0],scale[1],scale[2],cmds.ls('{0}.cv[*]'.format(shape)),r=True)
		#Scale a mesh
		elif Control.getType(ctrl) == 'mesh':
			for shape in shapes:
				cmds.scale(scale[0],scale[1],scale[2],cmds.ls('{0}.vtx[*]'.format(shape)),r=True)


	@staticmethod
	def getType(ctrl):
		'''
		'''
		if cmds.objExists(ctrl):
			if cmds.nodeType(ctrl) == 'transform':
				shape = cmds.listRelatives(ctrl,shapes=True)
				if shape:
					return cmds.nodeType(shape[0])

		return cmds.nodeType(ctrl)


	@staticmethod
	def getShapes(ctrl):
		'''
		'''
		return cmds.listRelatives(ctrl,shapes=True)		

class Guide(Control):
	def __init__(self,name,parent=str(),shape='sphere',color=0):
		super(Guide,self).__init__(name,parent,shape,color)


	def create(self):
		'''
		'''
		super(Guide,self).create()


	@staticmethod
	def createGuide(name,parent=str(),shape='sphere',color=0):
		guide = Guide(name,parent,shape,color)
		guide.create()

		return guide


def createSphere(name):
	shape = cmds.createNode('implicitSphere')
	trs = cmds.listRelatives(shape,p=True)[0]
	cmds.rename(trs,name)

	return name

def createCircle(name):
	trs = cmds.circle(ch=False)
	cmds.rename(trs,name)

	return name