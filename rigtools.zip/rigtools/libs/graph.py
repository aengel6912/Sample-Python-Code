'''
'''

#import just the Part class from part.py
from rigtools.parts.part import Part

class Graph(object):

	def __init__(self,name):
		'''
		Constructor method

		Parameters:
		name (str) = name of the element being built
		'''

		self._name = name
		self._parts = dict()
		self._partsOrder = []


	def addPart(self,name,part,parent):
		'''
		'''
		#if not isinstance(part,Part):
			#raise TypeError('{0} must be an instance of Part class'.format(part))

		self._parts[name] = {'part':part,'parent':parent}
		self._partsOrder.append(name)


	def insertPart(self,name,part,parent,index=0):
		'''
		'''
		self._partsOrder.insert(index,name)
		self._parts[name] = {'part':part,'parent':parent}


	def getPart(self,name):
		'''
		'''
		return self._parts[name]['part']


	def getParts(self):
		'''
		'''
		return [self._parts[name]['part'] for name in self._partsOrder]


	def getParent(self,name):
		'''
		'''
		if self._parts.has_key(name):
			return self._parts[name]['parent']


	def setParent(self,name,parent):
		'''
		'''
		if self._parts.has_key(name):
			self._parts[name]['parent'] = parent


	def getBuildOrder(self):
		'''
		'''
		buildOrder = list()
		partNameList = self._partsOrder
		partParentList = [self.getParent(name) for name in partNameList]
		childrenDict = {}

		for name in partNameList:
			if not self._parts[name]['parent'] in childrenDict.keys():
				childrenDict[self._parts[name]['parent']] = [name]
			else:
				childrenDict[self._parts[name]['parent']].append(name)

		for name in partNameList:
			children = list()

			if childrenDict.has_key(name):
				children = childrenDict[name]

			if self._parts[name]['part'] not in buildOrder:
				buildOrder.append(self._parts[name]['part'])

			for i,child in enumerate(children):
				if self._parts[child]['part'] in buildOrder:
					buildOrder.pop(buildOrder.index(self._parts[child]['part']))

				buildOrder.insert(buildOrder.index(self._parts[name]['part'])+(i+1),self._parts[child]['part'])

		return buildOrder