'''
Name module
A library of naming conventions
'''

#SUFFIXES
GROUP = 'GRP'
IK = 'IK'
FK = 'FK'
BLEND = 'BLD'
JOINT = 'JNT'
BLENDCOLORS = 'BCN'
MULTIPLYDIVIDE = 'MDN'
NULL = 'NULL'
ZERO = 'ZERO'
GUIDE = 'GUIDE'
CONTROL = 'CTL'
PLUSMINUSAVERAGE = 'PMA'
DECOMPOSEMATRIX = 'DCM'
VECTORPRODUCT = 'VPN'
POLEVECTOR = 'PVC'
REVERSE = 'RVN'
HANDLE = 'HDL'
LOCATOR = 'LOC'

#NAME TEMPLATES
NAMETEMPLATE = 'SIDE.LOCATION.DESCRIPTION.NUMBER.TYPE.NODETYPE'
DELIMITER ='_'
#ex: l_fr_upArm_001_ik_JNT

#SIDES
LEFT = 'l'
RIGHT = 'r'
CENTER = 'c'
MID = 'm'
SIDES ={'left':LEFT,'right':RIGHT,'center':CENTER,'mid':MID}


def getSide(name):
	'''
	Example:
	getSide('l_upArm_JNT')
	returns 'l'

	Gets side prefix from the given name

	Parameters:
	name(str): Name from which you get the side prefix

	returns the side prefix
	'''
	global DELIMITER
	global NAMETEMPLATE

	#Check that side's name is a string
	if not isinstance(name, basestring):
		raise TypeError('{0} must be a string'.format(name))
	#Check that delimiter is used in side's name
	elif not DELIMITER in name:
		raise RuntimeError('{0} must use {1} in naming'.format(name,DELIMITER))

	#Isolate side prefix from a name that includes delimiters
	nameSplit = name.split(DELIMITER)

	if nameSplit[0] in SIDES.values():
		return nameSplit[0]
	print '{0} must follow {1} naming convention'.format(name,NAMETEMPLATE)

	return name

#LOCATIONS
FRONT = 'frt'
BACK = 'bck'
MIDDLE = 'mid'
TOP = 'top'
BOTTOM = 'bot'
LOCATIONS = {'front':FRONT,'back':BACK,'middle':MIDDLE,'top':TOP,'bottom':BOTTOM}


def getLocation(name):
	'''
	Gets location prefix from the given name

	Example:
	getLocation('l_frt_upArm_JNT')
	returns 'frt'

	Parameters:
	name(str): Name from which you get the side prefix

	returns the location prefix
	'''
	global DELIMITER
	global NAMETEMPLATE

	if not isinstance(name, basestring):
		raise TypeError('{0} must be a string'.format(name))
	elif not DELIMITER in name:
		raise RuntimeError('{0} must use {1} in naming'.format(name,DELIMITER))

	nameSplit = name.split(DELIMITER)
	if nameSplit[1] in LOCATIONS.values():
		return nameSplit[0]
	else:
		print '{0} does not have a location'.format(name)
		return None

#COLORS
BLUE = 6
RED = 13
YELLOW = 17


#NUMBER PADDING
def padNumber(number,padding=3):
	'''
	Pads numbers
	'''
	pass

