'''
'''
import maya.cmds as cmds
def switch(attr, name=None, value=0, choices=None, outputs=None):
	'''
	'''

	attrNode = name
	attrName = attr
	attrPath = '{0}.{1}'.format(attrNode, attrName)

	#Create enum attribute
	cmds.addAttr(name, ln=attr, at='enum', enumName=':'.join(choices), dv=value, keyable=True)
	choiceNode = cmds.createNode ('choice', name=attrNode + attrName + 'choice')
	cmds.connectAttr(attrPath, '{0}.selector'.format(choiceNode),f=True)

	#Add attributes
	for i in range (len(outputs)):
		attr = 'output{0}'.format(i)

		if isinstance (outputs[i],list) or isinstance(outputs[i],tuple):
			cmds.addAttr(choiceNode, ln=attr, at='double3', keyable=True)
			cmds.addAttr(choiceNode, ln=attr + 'X', at='double', dv=outputs[i][0], parent=attr, keyable=True)
			cmds.addAttr(choiceNode, ln=attr + 'Y', at='double', dv=outputs[i][1], parent=attr, keyable=True)
			cmds.addAttr(choiceNode, ln=attr + 'Z', at='double', dv=outputs[i][2], parent=attr, keyable=True)

			cmds.connectAttr('{0}.{1}'.format(choiceNode, attr), '{0}.input[{1}]'.format(choiceNode, i), f=True)

	return choiceNode +'.output'


def lockAttr(node,attr):
	'''
	'''
	resolvedAttr = '{0}.{1}'.format(node,attr)
	cmds.setAttr(resolvedAttr,lock=True)


def hideAttr(node,attr):
	'''
	'''
	resolvedAttr = '{0}.{1}'.format(node,attr)
	cmds.setAttr(resolvedAttr,keyable=False,channelBox=False)


def lockAndHideAttr(node,attr):
	'''
	'''
	lockAttr(node,attr)
	hideAttr(node,attr)