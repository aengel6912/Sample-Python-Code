'''
mayaObject module
'''

#Import maya modules
import maya.cmds as cmds

class MayaObject(object):
	def __init__(self,name,parent=str(),position=(0,0,0)):
		'''
		'''
		self._name = name
		self._parent = parent
		self.setParent(parent)
		self._position = position


	def getName(self):
		'''
		'''
		return self._name


	def getParent(self):
		'''
		'''
		parent = self._parent

		if cmds.objExists(self._name):
			parent = cmds.listRelatives(self._name,p=True) or str()
			if parent:
				parent = parent[0]

		return parent

	def getPosition(self):
		'''
		'''
		return self._position

	def setPosition(self,value):
		'''
		'''
		#check for errors
		if not isinstance(value,(list,tuple)):
			raise TypeError('{0} must be list or tuple with length of 3'.format(value))
		elif not len(value) == 3:
			raise RuntimeError('{0} must be list or tuple with length of 3'.format(value))

		#move object to passed in value
		if cmds.objExists(self._name):
			cmds.xform(self._name,ws=True,t=value)	

		self._position = value

	def setName(self,value):
		'''
		'''
		if not isinstance(value,basestring):
			raise TypeError('{0} must be a string'.format(value))	

		if cmds.objExists(self._name):
			cmds.rename(self._name,value)

		self._name = value


	def setParent(self,value):
		'''
		'''
		if not isinstance(value,basestring):
			raise TypeError('{0} must be a string'.format(value))

		if cmds.objExists(self._name):
			parent = self.getParent()
			if cmds.objExists(value) and parent != value:
				cmds.parent(self._name,value)

		self._parent = value

	def create(self):
		'''
		creates an empty transform node
		'''
		if not cmds.objExists(self.getName()):
			cmds.createNode('transform',n=self.getName())